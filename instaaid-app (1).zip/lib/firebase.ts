import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"

const firebaseConfig = {
  apiKey: "AIzaSyCEUbhzS4e1Kp43iqaDOlrG6rbHE4ZIE38",
  authDomain: "thesis01-85abf.firebaseapp.com",
  projectId: "thesis01-85abf",
  storageBucket: "thesis01-85abf.firebasestorage.app",
  messagingSenderId: "253320152476",
  appId: "1:253320152476:web:51ce11a6cc062dfb2af459",
  measurementId: "G-7TFR4XCC7Y",
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export default app
