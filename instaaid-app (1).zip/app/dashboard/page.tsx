"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Home, Phone, AlertTriangle, User, Settings } from "lucide-react"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("home")

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-blue-800 px-4 py-4">
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          <div className="flex items-center space-x-3">
            <div className="bg-white rounded-full p-2">
              <Image
                src="/images/instaaid-logo.png"
                alt="InstaAid Logo"
                width={40}
                height={40}
                className="object-contain"
              />
            </div>
            <h1 className="text-white text-sm sm:text-lg font-semibold">InstaAid Emergency Response</h1>
          </div>
          <Button variant="ghost" size="sm" className="text-white">
            <Settings className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 pb-20 max-w-4xl mx-auto">
        {activeTab === "home" && (
          <div className="p-4 sm:p-6 space-y-6">
            {/* Quick Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Link href="/emergency/sos">
                <div className="bg-red-500 hover:bg-red-600 text-white p-4 sm:p-6 rounded-lg text-center transition-colors">
                  <AlertTriangle className="w-6 h-6 sm:w-8 sm:h-8 mx-auto mb-2" />
                  <h3 className="font-semibold text-sm sm:text-base">Emergency SOS</h3>
                  <p className="text-xs sm:text-sm opacity-90">Quick emergency alert</p>
                </div>
              </Link>

              <Link href="/emergency/combined">
                <div className="bg-blue-500 hover:bg-blue-600 text-white p-4 sm:p-6 rounded-lg text-center transition-colors">
                  <Phone className="w-6 h-6 sm:w-8 sm:h-8 mx-auto mb-2" />
                  <h3 className="font-semibold text-sm sm:text-base">Emergency Hub</h3>
                  <p className="text-xs sm:text-sm opacity-90">Services & Reports</p>
                </div>
              </Link>
            </div>

            {/* Status Overview */}
            <div className="bg-white rounded-lg p-4 sm:p-6 shadow-sm">
              <h2 className="text-base sm:text-lg font-semibold text-gray-900 mb-4">System Status</h2>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm sm:text-base text-gray-600">GPS Status</span>
                  <span className="text-sm sm:text-base text-green-600 font-medium">Good</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm sm:text-base text-gray-600">Network</span>
                  <span className="text-sm sm:text-base text-green-600 font-medium">5G/20mbps</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm sm:text-base text-gray-600">Sensors</span>
                  <span className="text-sm sm:text-base text-green-600 font-medium">Good</span>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-lg p-4 sm:p-6 shadow-sm">
              <h2 className="text-base sm:text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
              <div className="text-center py-6 sm:py-8 text-gray-500">
                <AlertTriangle className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm sm:text-base">No recent emergency reports</p>
                <p className="text-xs sm:text-sm">Stay safe on the road!</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "profile" && (
          <div className="p-4 sm:p-6">
            <Link href="/dashboard/profile">
              <div className="bg-white rounded-lg p-4 sm:p-6 shadow-sm text-center">
                <User className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-4 text-gray-400" />
                <h2 className="text-base sm:text-lg font-semibold text-gray-900 mb-2">User Profile</h2>
                <p className="text-sm sm:text-base text-gray-600">Manage your account settings</p>
              </div>
            </Link>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-200 border-t border-gray-300">
        <div className="flex max-w-4xl mx-auto">
          <button
            onClick={() => setActiveTab("home")}
            className={`flex-1 py-2 sm:py-3 px-2 sm:px-4 text-center ${activeTab === "home" ? "text-blue-600" : "text-gray-600"}`}
          >
            <Home className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-1" />
            <span className="text-xs">Home</span>
          </button>

          <Link href="/emergency/combined" className="flex-1 py-2 sm:py-3 px-2 sm:px-4 text-center text-gray-600">
            <AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-1" />
            <span className="text-xs">Reports</span>
          </Link>

          <Link href="/dashboard/profile" className="flex-1 py-2 sm:py-3 px-2 sm:px-4 text-center text-gray-600">
            <User className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-1" />
            <span className="text-xs">Profile</span>
          </Link>
        </div>
      </div>
    </div>
  )
}
