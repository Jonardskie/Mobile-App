import type React from "react" // 🔷 TypeScript: importing React types
import type { Metadata } from "next" // 🔷 TypeScript: Next.js metadata type
import { GeistSans } from "geist/font/sans" // 🔤 Font: Modern sans-serif font
import { GeistMono } from "geist/font/mono" // 🔤 Font: Monospace font (for code)
import "./globals.css" // 🎨 Global CSS styles (Tailwind + custom styles)
import { AuthProvider } from "@/hooks/use-auth" // 🔐 Authentication context provider
import { ThemeProvider } from "next-themes" // 🌙 Dark/light theme provider

// 📄 SEO METADATA - appears in browser tab and search results
export const metadata: Metadata = {
  title: "v0 App", // 📝 Browser tab title
  description: "Created with v0", // 📝 Search engine description
  generator: "v0.app", // 🏷️ Indicates this was built with v0
}

// 🏗️ ROOT LAYOUT COMPONENT
// This function wraps every page in your app
export default function RootLayout({
  children, // 👶 This represents the current page content
}: {
  children: React.ReactNode // 🔷 TypeScript: children can be any React element
}) {
  return (
    // 🌐 HTML ROOT ELEMENT
    <html lang="en">
      <head>
        {/* 
        🎨 INLINE FONT STYLES
        This sets up the font families for the entire app
        We're using CSS custom properties (variables) for flexibility
        */}
        <style>{`
html {
  font-family: ${GeistSans.style.fontFamily}; /* 🔤 Default font for the entire site */
  --font-sans: ${GeistSans.variable}; /* 📝 CSS variable for sans-serif font */
  --font-mono: ${GeistMono.variable}; /* 📝 CSS variable for monospace font */
}
        `}</style>
      </head>
      {/* 
      📦 BODY ELEMENT
      Contains all visible content of your app
      */}
      <body className={`${GeistSans.variable} ${GeistMono.variable} antialiased`}>
        {/* 
        🎨 BODY CLASSES EXPLANATION:
        - ${GeistSans.variable} = Makes sans-serif font available as CSS variable
        - ${GeistMono.variable} = Makes monospace font available as CSS variable  
        - antialiased = Smooth font rendering (reduces pixelation)
        */}

        {/* 
        🔐 AUTHENTICATION PROVIDER
        Wraps the entire app to provide user authentication state
        Any component can access login status, user data, etc.
        */}
        <AuthProvider>
          {/* 
          🌙 THEME PROVIDER
          Enables dark/light mode switching throughout the app
          - attribute="class" = Uses CSS classes for theming (.dark, .light)
          - defaultTheme="system" = Follows user's OS preference
          - enableSystem = Allows automatic OS theme detection
          - disableTransitionOnChange = Prevents flash during theme switch
          */}
          <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
            {children}
          </ThemeProvider>
        </AuthProvider>
      </body>
    </html>
  )
}

/* 
🏗️ LAYOUT STRUCTURE SUMMARY:
1. Root Layout = Master template for all pages
2. Metadata = SEO and browser information
3. Font Setup = Typography configuration
4. Provider Pattern = Shared state (auth, themes) across all pages
5. Children = Dynamic content (changes based on current page)

🔄 HOW IT WORKS:
When you visit any page, Next.js:
1. Loads this layout first
2. Inserts the page content where {children} is
3. Applies all the providers (auth, theme) to that page
4. Renders the complete HTML structure

⚠️ HYDRATION NOTE:
Hydration errors occur when server-rendered HTML doesn't match client-rendered HTML.
Common causes: extra whitespace, conditional rendering, browser-only APIs.
Always keep HTML structure clean and consistent between server and client.
*/
